<--1-->
<!doctype html>
<html lang="en"> 
	<head>
		<title>Web Project</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" type="text/css" href="style.css">
		<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.2/font/bootstrap-icons.css">

	</head>
	<body >
		
		<header class="py-4 px-4">
			<div class="container-fluid">
				<div class="row">
					<div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 ">
						<a href="#"><img src="images/logo.png" alt="logo" class="logo"></a>
					</div>
					<div class="col-xl-9 col-lg-9 col-md-9 col-sm-6 d-flex align-items-center">
						<div class="ms-auto"><a class="login" href="#">Login</a></div>
						<button class="btn btnbar" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasScrolling" aria-controls="offcanvasScrolling"><img src="images/index.png" alt="menu"></button>
						
					</div>
				</div>
			</div>
			<div class="offcanvas offcanvas-start" data-bs-scroll="true" data-bs-backdrop="false" tabindex="-1" id="offcanvasScrolling" aria-labelledby="offcanvasScrollingLabel" style="width: 250px; background-color: #e90102;">
			  <div class="offcanvas-header d-flex">
				<div class="navbar " >
					<ul class="navbar-nav ">
					  <li class="nav-item">
						<a class="nav-link text-dark" href="#">HOME</a>
					  </li>
					  <li class="nav-item">
						<a class="nav-link " href="#about">ABOUT</a>
					  </li>
					  <li class="nav-item">
						<a class="nav-link" href="#classes">CLASSES</a>
					  </li>
					  <li class="nav-item">
						
						<a class="nav-link" href="#testimonial">Testimonials</a>
					  </li>
					   <li class="nav-item">
						<a class="nav-link" href="#contact">CONTACT</a>
					  </li>
					</ul>
				</div>
				<button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close" style="margin-top: -233px;"></button>
			  </div>
			</div>
		</header>
		<section class="banner_main ">
			<div id="demo" class="carousel slide" data-bs-ride="carousel">

			  <!-- Indicators/dots -->
			  <div class="carousel-indicators">
				<ol>
				  <li  data-bs-target="#demo" data-bs-slide-to="0" class="active"></li>
				  <li  data-bs-target="#demo" data-bs-slide-to="1"></li>
				  <li  data-bs-target="#demo" data-bs-slide-to="2"></li>
				  <li  data-bs-target="#demo" data-bs-slide-to="3"></li>
				</ol>
			  </div>
			  
			  <!-- The slideshow/carousel -->
			  <div class="carousel-inner">
				<div class="carousel-item active ">
					<div class="container">
						<div class="row">
							<div class="col-xl-5 col-lg-5 col-md-12 col-sm-12 slider">
								<h1>skating<span class="midil_img"> board</span></h1>
								<p class="sliderp">It is a long established fact that a reader will be<br>
								distracted by the readable content of a page when<br>
								looking at its</p>
								<a class="read_more" href="">READ MORE</a>

							</div>
							<div class="col-xl-7 col-lg-12 col-md-7 ">

								<img src="images/ima.png" alt="Los Angeles" class="sliderimg">
							</div>
							
						</div>
					</div>
					
				</div>
				<div class="carousel-item ">
					<div class="container">
						<div class="row">
							<div class="col-xl-5 col-lg-5 col-md-12 col-sm-12 slider">
								<h1>skating<span class="midil_img"> board</span></h1>
								<p class="sliderp">It is a long established fact that a reader will be<br>
								distracted by the readable content of a page when<br>
								looking at its</p>
								<a class="read_more" href="">READ MORE</a>

							</div>
							<div class="col-xl-7 col-lg-12 col-md-7 ">

								<img src="images/ima.png" alt="Los Angeles" class="sliderimg">
							</div>
						</div>
					</div>
				</div>
				<div class="carousel-item ">
					<div class="container">
						<div class="row">
							<div class="col-xl-5 col-lg-5 col-md-12 col-sm-12 slider">
								<h1>skating<span class="midil_img"> board</span></h1>
								<p class="sliderp">It is a long established fact that a reader will be<br>
								distracted by the readable content of a page when<br>
								looking at its</p>
								<a class="read_more" href="">READ MORE</a>

							</div>
							<div class="col-xl-7 col-lg-12 col-md-7 ">

								<img src="images/ima.png" alt="Los Angeles" class="sliderimg">
							</div>
						</div>
					</div>
				</div>
				<div class="carousel-item ">
					<div class="container">
						<div class="row">
							<div class="col-xl-5 col-lg-5 col-md-12 col-sm-12 slider">
								<h1>skating<span class="midil_img"> board</span></h1>
								<p class="sliderp">It is a long established fact that a reader will be<br>
								distracted by the readable content of a page when<br>
								looking at its</p>
								<a class="read_more" href="">READ MORE</a>

							</div>
							<div class="col-xl-7 col-lg-12 col-md-7 ">

								<img src="images/ima.png" alt="Los Angeles" class="sliderimg">
							</div>
						</div>
					</div>
				</div>
			  </div>  
			</div>
			

		</section >
		<section>
			<div id="about" class="about afbecros">
			  <div class="container">
				<div class="row">
				  <div class="col-md-12 col-sm-12 text-center">
					<div class="titlepage">
					  <h2 style="padding-left: 33%;">About</h2>
					 <img style="margin-top: 140px;" src="images/about_img.png" alt=" image" class="img-fluid">
					  <p class="mb-5 pb-4">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it It is a long established fact that a reader will be distracted by the readable content of a page when lookingusing Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it</p>
					  <a class="read_morebtn" href="">Read More</a></div>
				  </div>
				</div>
			  </div>
			</div>
		</section>
		<section>
			<div class="classes afbecros" id="classes">
			  <div class="container">
				<div class="row pb-5 mb-5 pb-5">
				  <div class="col-md-12 mb-5">
					<div class="titlepage mb-5">
					  <h2 style="padding-left: 32%;">classes</h2>
					</div>
				  </div>
				</div>
				<div class="row mt-5 pt-5">
				  <div class="col-md-4 col-sm-12 ">
					<div class="classes_box  text-center">
					  <figure><img src="images/classes_img1.png" alt="website template image"></figure>
					  <h3>skating</h3>
					</div>
				  </div>
				  <div class="col-md-4 col-sm-12">
					<div class="classes_box text-center">
					  <figure><img src="images/classes_img2.png" alt="website template image"></figure>
					  <h3>skating</h3>
					</div>
				  </div>
				  <div class="col-md-4 col-sm-12">
					<div class="classes_box  text-center">
					  <figure><img src="images/classes_img3.png" alt="website template image"></figure>
					  <h3>skating</h3>
					</div>
				  </div>
				  <div class="col-md-12 mt-5 ">
					<div class="p_fulltext text-center">
					  <p class="mb-5 pb-4">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it It is a long established fact that a reader will be distracted by the readable content of a page when lookingusing Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it</p>
					  <a class="read_morebtn" href="">Read More</a></div>
				  </div>
				</div>
			  </div>
			</div>
		</section>
		<section>
			<div id="testimonial" class="testimonial afbecros ">
			  <div class="container">
				<div class="row">
				  <div class="col-md-12">
					<div class="titlepage">
					  <h2 style="padding-left: 25.5%;">Testimonials</h2>
					</div>
				  </div>
				</div>
				<div class="row mt-5 pt-5">
				  <div class="col-md-12 mt-5 pt-5">
					<div id="myCarousel" class="carousel slide testimonial_Carousel" data-bs-ride="carousel">
					  <ol class="carousel-indicators ">
						<li data-bs-target="#myCarousel" data-bs-slide-to="0" class="active"></li>
						<li data-bs-target="#myCarousel" data-bs-slide-to="1"></li>
						<li data-bs-target="#myCarousel" data-bs-slide-to="2"></li>
					  </ol>
					  <div class="carousel-inner mt-5 ">
						<div class="carousel-item active">
						  <div class="container">
							
							  <div class="row">
								<div class="col-md-12">
								  <div class="testimonial_box">
									<h3>markden</h3>
									<p>ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitationipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation</p>
								  </div>
								</div>
							  </div>
						   
						  </div>
						</div>
						<div class="carousel-item">
						  <div class="container">
							  <div class="row">
								<div class="col-md-12">
								  <div class="testimonial_box">
									<h3>markden</h3>
									<p>ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitationipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation</p>
								  </div>
								</div>
							  </div>
						  
						  </div>
						</div>
						<div class="carousel-item">
						  <div class="container">
							  <div class="row">
								<div class="col-md-12">
								  <div class="testimonial_box">
									<h3>markden</h3>
									<p>ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitationipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation</p>
								  </div>
								</div>
							  </div>
						   
						  </div>
						</div>
					  </div> 
					  </div>
				  </div>
				</div>
			  </div>
			</div>
		</section>
		<section>
			<div id="contact" class="contact afbecros">
			  <div class="container">
				<div class="row">
				  <div class="col-md-12">
					<div class="titlepage">
					  <h2 style="padding-left: 28%;">Contact Us</h2>
					</div>
				  </div>
				</div>
				<div class="row mt-5 pt-5">
				  <div class="col-md-10 offset-md-1 mt-5 pt-5">
					<form action="#" method="post" class="main_form  pt-5" id="request">
					  <div class="row">
						<div class="col-md-12">
						  <input class="contactus" placeholder="Name" type="type" name="Name">
						</div>
						<div class="col-md-12">
						  <input class="contactus" placeholder="Phone Number" type="type" name="Phone Number">
						</div>
						<div class="col-md-12">
						  <input class="contactus" placeholder="Email" type="type" name="Email">
						</div>
						<div class="col-md-12">
						  <input class="contactusmess" placeholder="Message" type="type" Message="Name">
						</div>
						<div class="col-md-12">
						  <button class="send_btn">Send</button>
						</div>
					  </div>
					</form>
				  </div>
				</div>
			  </div>
			</div>
		</section>
		<footer>
			<div class="footer">
				<div class="container">
				  <div class="row">
					<div class="col-md-8 offset-md-2">
					  <div class="fid_box">
						<ul class="location_icon">
						  <li><a href=""><i class="bi bi-geo-alt-fill" style="font-size: 30px;"></i></a><br><br>
							Location</li>
						  <li><a href=""><i class="bi bi-telephone-fill" style="font-size: 30px;"></i></a><br><br>
							+01 1234567890</li>
						  <li><a href=""><i class="bi bi-envelope-fill" style="font-size: 40px;"></i></a><br><br>
							mail@domain.com</li>
						</ul>
					  </div>
					</div>
					<div class="col-md-12">
					  <div class="dolor">
						<p>ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitationipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation</p>
					  </div>
					</div>
				  </div>
				</div>
				<div class="copyright mt-5">
				  <div class="container">
					<div class="row">
					  <div class="col-md-12">
						<p>&copy; 2045 All Rights Reserved. Design by <a target="_blank" class="design" href="">HTML Design</a></p>
					  </div>
					</div>
				  </div>
				</div>
			</div>
		</footer>
		<script src="js/bootstrap.bundle.min.js"></script>
	</body>
</html>